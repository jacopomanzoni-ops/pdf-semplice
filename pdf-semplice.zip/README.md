# PDF Semplice

App Android senza pubblicità per aprire, leggere, compilare e salvare i PDF.

## Cosa fa

- **Apre i PDF** dal telefono, oppure da "Apri con…" nel file manager, nelle email o su WhatsApp
- **Scrivi**: tocca un punto qualsiasi del foglio e scrivi il testo, ad esempio nome, cognome o data
- **Compila campi del modulo**: se il PDF ha già i campi compilabili, li mostra in un elenco da riempire
- **Annulla** l'ultima modifica, anche più volte di fila
- **Salva** sopra l'originale, oppure **Salva come copia**, oppure **Condividi**
- **Zoom** con due dita (allarga o stringi), oppure con i pulsanti **−** e **+** in basso, fino al 300%. Dal menu ⋮ "Zoom normale" torna al 100%

## Installazione

1. Apri la pagina **Releases** del repository dal telefono e scarica `PDF-Semplice.apk`
2. Apri il file scaricato. Android ti chiederà di consentire l'installazione da questa fonte: accetta
3. Gli aggiornamenti si installano sopra la versione precedente, senza bisogno di disinstallarla

## Limiti

- Il testo usa il font Helvetica. Le lettere accentate italiane funzionano, le emoji no
- I PDF protetti da password per l'apertura non si possono aprire
- I moduli in formato XFA, quelli vecchi di Adobe, non sono supportati. Su quei moduli puoi comunque usare "Scrivi"

## Compilazione

GitHub compila l'APK da solo a ogni modifica, con la procedura in `.github/workflows/build.yml`.
Se vuoi compilarlo sul tuo computer, apri la cartella con Android Studio.

Per modificare i PDF l'app usa la libreria open source [PdfBox-Android](https://github.com/TomRoush/PdfBox-Android) (licenza Apache 2.0).
