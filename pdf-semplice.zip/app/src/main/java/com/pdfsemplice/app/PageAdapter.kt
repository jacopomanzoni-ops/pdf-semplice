package com.pdfsemplice.app

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

/** Mostra le pagine del PDF una sotto l'altra. */
class PageAdapter(
    private val scope: CoroutineScope,
    /** pagina, x e y in punti PDF dall'angolo in alto a sinistra */
    private val onTap: (page: Int, x: Float, y: Float) -> Unit,
) : RecyclerView.Adapter<PageAdapter.Holder>() {

    private val mutex = Mutex()
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var sizes: List<Pair<Float, Float>> = emptyList() // larghezza, altezza in punti
    private var generation = 0

    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 4).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    /** Apre (o riapre dopo una modifica) il file da mostrare. */
    suspend fun setFile(file: File) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                renderer?.close()
                pfd?.close()
                val p = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = try {
                    PdfRenderer(p)
                } catch (e: Exception) {
                    p.close()
                    renderer = null
                    pfd = null
                    throw e
                }
                pfd = p
                renderer = r
                sizes = (0 until r.pageCount).map { i ->
                    r.openPage(i).use { it.width.toFloat() to it.height.toFloat() }
                }
                generation++
            }
        }
        cache.evictAll()
        notifyDataSetChanged()
    }

    fun close() {
        scope.launch(Dispatchers.IO) {
            mutex.withLock {
                renderer?.close(); renderer = null
                pfd?.close(); pfd = null
            }
        }
    }

    private var recyclerView: RecyclerView? = null

    override fun onAttachedToRecyclerView(rv: RecyclerView) {
        recyclerView = rv
        // se la larghezza cambia (rotazione, zoom) ridisegna le pagine
        rv.addOnLayoutChangeListener { _, l, _, r, _, ol, _, or, _ ->
            if (r - l != or - ol && itemCount > 0) rv.post { notifyDataSetChanged() }
        }
    }

    override fun onDetachedFromRecyclerView(rv: RecyclerView) {
        recyclerView = null
    }

    override fun getItemCount() = sizes.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_page, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(position)

    override fun onViewRecycled(holder: Holder) {
        holder.job?.cancel()
        holder.image.setImageBitmap(null)
    }

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.pageImage)
        private val number: TextView = view.findViewById(R.id.pageNumber)
        var job: Job? = null

        private val detector = GestureDetector(view.context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION || image.width == 0) return false
                val (pw, ph) = sizes[pos]
                onTap(pos, e.x * pw / image.width, e.y * ph / image.height)
                return true
            }
        })

        init {
            @SuppressLint("ClickableViewAccessibility")
            image.setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }
        }

        fun bind(position: Int) {
            val (pw, ph) = sizes[position]
            number.text = "${position + 1} / ${sizes.size}"

            // NB: qui la vista non è ancora attaccata, quindi la larghezza
            // va presa dalla lista e non da itemView.parent
            val rv = recyclerView
            val rvWidth = rv?.let { it.width - it.paddingLeft - it.paddingRight } ?: 0
            if (rvWidth <= 0) {
                // la lista non è ancora stata misurata: riprova appena pronta
                rv?.post { notifyItemChanged(position) }
                return
            }
            val width = (rvWidth - itemView.paddingLeft - itemView.paddingRight).coerceAtLeast(1)
            val height = (width * ph / pw).roundToInt()
            image.layoutParams = image.layoutParams.apply { this.height = height }

            // limite alla risoluzione per non esaurire la memoria
            val bw = min(width, 2000)
            val bh = (bw * ph / pw).roundToInt().coerceAtLeast(1)
            val key = "$generation-$position-$bw"

            job?.cancel()
            val cached = cache.get(key)
            if (cached != null) {
                image.setImageBitmap(cached)
                return
            }
            image.setImageBitmap(null)
            val gen = generation
            job = scope.launch {
                val bmp = withContext(Dispatchers.Default) {
                    mutex.withLock {
                        val r = renderer ?: return@withLock null
                        if (gen != generation || position >= r.pageCount) return@withLock null
                        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                        b.eraseColor(Color.WHITE)
                        r.openPage(position).use {
                            it.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        }
                        b
                    }
                } ?: return@launch
                cache.put(key, bmp)
                if (bindingAdapterPosition == position) image.setImageBitmap(bmp)
            }
        }
    }
}
