package com.pdfsemplice.app

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDAcroForm
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDChoice
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import com.tom_roush.pdfbox.util.Matrix
import java.io.File

/**
 * Tiene una copia di lavoro del PDF nella cache dell'app.
 * Ogni modifica viene scritta subito sulla copia (così quello che vedi è
 * esattamente quello che verrà salvato); il file originale viene toccato
 * solo quando premi "Salva".
 */
class PdfSession(private val context: Context) {

    val workFile = File(context.cacheDir, "work.pdf")
    private val undoStack = ArrayDeque<File>()

    /** Ci sono modifiche non ancora salvate. */
    var dirty = false

    val canUndo get() = undoStack.isNotEmpty()

    fun load(uri: Uri) {
        clearUndo()
        val tmp = File(context.cacheDir, "incoming.pdf")
        context.contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { input.copyTo(it) }
        } ?: error("Impossibile leggere il file")
        tmp.copyTo(workFile, overwrite = true)
        tmp.delete()
        dirty = false
    }

    fun markSaved() {
        dirty = false
    }

    fun undo(): Boolean {
        val f = undoStack.removeLastOrNull() ?: return false
        f.copyTo(workFile, overwrite = true)
        f.delete()
        dirty = true
        return true
    }

    private fun clearUndo() {
        undoStack.forEach { it.delete() }
        undoStack.clear()
    }

    /** Apre la copia di lavoro, applica [block] e la riscrive. */
    private fun <T> edit(block: (PDDocument) -> T): T {
        val tmp = File(context.cacheDir, "editing.pdf")
        val result = PDDocument.load(workFile).use { doc ->
            if (doc.isEncrypted) doc.isAllSecurityToBeRemoved = true
            val r = block(doc)
            doc.save(tmp)
            r
        }
        // salva lo stato precedente per "Annulla"
        val snapshot = File(context.cacheDir, "undo_${System.nanoTime()}.pdf")
        workFile.copyTo(snapshot, overwrite = true)
        undoStack.addLast(snapshot)
        while (undoStack.size > 30) undoStack.removeFirst().delete()

        tmp.copyTo(workFile, overwrite = true)
        tmp.delete()
        dirty = true
        return result
    }

    // ---------------------------------------------------------------- testo

    /**
     * Scrive [text] sulla pagina [pageIndex].
     * [x] e [yTop] sono in punti PDF, misurati dall'angolo in alto a sinistra
     * della pagina così come la vedi a schermo (rotazione compresa).
     * [yTop] indica dove sta il bordo superiore della prima riga.
     */
    fun addText(pageIndex: Int, x: Float, yTop: Float, text: String, fontSize: Float) {
        edit { doc ->
            val page = doc.getPage(pageIndex)
            val box = page.cropBox
            val w = box.width
            val h = box.height
            val rot = ((page.rotation % 360) + 360) % 360

            // Matrice che porta dalle coordinate "a schermo" (origine in basso
            // a sinistra, y verso l'alto) a quelle della pagina non ruotata.
            val ox = box.lowerLeftX
            val oy = box.lowerLeftY
            val shown = when (rot) {
                90 -> Matrix(0f, 1f, -1f, 0f, ox + w, oy)
                180 -> Matrix(-1f, 0f, 0f, -1f, ox + w, oy + h)
                270 -> Matrix(0f, -1f, 1f, 0f, ox, oy + h)
                else -> Matrix(1f, 0f, 0f, 1f, ox, oy)
            }
            val displayHeight = if (rot == 90 || rot == 270) w else h

            val font = PDType1Font.HELVETICA
            val lines = text.replace("\r", "").split("\n")
            // controlla subito i caratteri non supportati, prima di scrivere
            lines.forEach { font.getStringWidth(it) }

            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                cs.saveGraphicsState()
                cs.transform(shown)
                cs.beginText()
                cs.setFont(font, fontSize)
                cs.setNonStrokingColor(0f, 0f, 0f)
                val baseline = displayHeight - yTop - fontSize * 0.8f
                cs.newLineAtOffset(x, baseline)
                lines.forEachIndexed { i, line ->
                    if (i > 0) cs.newLineAtOffset(0f, -fontSize * 1.2f)
                    cs.showText(line)
                }
                cs.endText()
                cs.restoreGraphicsState()
            }
        }
    }

    // --------------------------------------------------------------- moduli

    enum class Kind { TEXT, CHECK, CHOICE }

    data class Field(
        val name: String,
        val label: String,
        val kind: Kind,
        val value: String,
        val options: List<String>,
        val multiline: Boolean,
    )

    class FormInfo(val fields: List<Field>, val isXfaOnly: Boolean)

    fun readForm(): FormInfo {
        PDDocument.load(workFile).use { doc ->
            val form = doc.documentCatalog.acroForm ?: return FormInfo(emptyList(), false)
            val out = mutableListOf<Field>()
            for (f in form.fieldTree) {
                if (f.isReadOnly) continue
                val name = f.fullyQualifiedName ?: continue
                val label = f.alternateFieldName?.takeIf { it.isNotBlank() }
                    ?: f.partialName?.takeIf { it.isNotBlank() }
                    ?: name
                when (f) {
                    is PDTextField -> out += Field(name, label, Kind.TEXT, f.value ?: "", emptyList(), f.isMultiline)
                    is PDCheckBox -> out += Field(name, label, Kind.CHECK, if (f.isChecked) "1" else "", emptyList(), false)
                    is PDRadioButton -> out += Field(name, label, Kind.CHOICE, f.value ?: "", f.onValues.toList(), false)
                    is PDChoice -> out += Field(name, label, Kind.CHOICE, f.value.firstOrNull() ?: "", f.options, false)
                    else -> {} // firme e pulsanti: ignorati
                }
            }
            return FormInfo(out, out.isEmpty() && form.hasXFA())
        }
    }

    /** Applica i valori; restituisce i nomi dei campi che non è stato possibile compilare. */
    fun fillForm(values: Map<String, String>): List<String> = edit { doc ->
        val form = doc.documentCatalog.acroForm ?: return@edit values.keys.toList()
        ensureDefaultFont(form)
        val failed = mutableListOf<String>()
        for ((name, value) in values) {
            try {
                when (val f = form.getField(name)) {
                    is PDTextField -> f.value = value
                    is PDCheckBox -> if (value.isNotEmpty()) f.check() else f.unCheck()
                    is PDRadioButton -> if (value.isNotEmpty()) f.value = value
                    is PDChoice -> if (value.isNotEmpty()) f.setValue(value)
                    else -> {}
                }
            } catch (e: Exception) {
                failed += name
            }
        }
        try {
            form.refreshAppearances()
        } catch (_: Exception) {
        }
        failed
    }

    private fun ensureDefaultFont(form: PDAcroForm) {
        var res = form.defaultResources
        if (res == null) {
            res = PDResources()
            form.defaultResources = res
        }
        val helv = COSName.getPDFName("Helv")
        if (res.getFont(helv) == null) res.put(helv, PDType1Font.HELVETICA)
        if (form.defaultAppearance.isNullOrBlank()) form.defaultAppearance = "/Helv 0 Tf 0 g"
    }
}
