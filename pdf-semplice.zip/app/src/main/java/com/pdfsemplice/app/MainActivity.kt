package com.pdfsemplice.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.doOnNextLayout
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var session: PdfSession
    private lateinit var pageAdapter: PageAdapter
    private lateinit var toolbar: MaterialToolbar
    private lateinit var recycler: RecyclerView
    private lateinit var hscroll: HorizontalScrollView
    private lateinit var emptyView: View
    private lateinit var hintBar: TextView
    private lateinit var progress: ProgressBar
    private lateinit var zoomBar: View
    private lateinit var zoomLabel: TextView

    private var currentUri: Uri? = null
    private var currentName = "documento.pdf"
    private var hasDocument = false
    private var textMode = false
    private var busy = false
    private var lastFontSize = 11f

    // zoom: 1 = pagina larga quanto lo schermo
    private val minZoom = 1f
    private val maxZoom = 3f
    private val zoomSteps = floatArrayOf(1f, 1.25f, 1.5f, 2f, 2.5f, 3f)
    private var zoom = 1f

    // zoom con due dita
    private var pinching = false
    private var childrenCancelled = false
    private var pinchStartZoom = 1f
    private var pinchFactor = 1f
    private var pinchFx = 0f
    private var pinchFy = 0f
    private lateinit var scaleDetector: ScaleGestureDetector

    private val openLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                openUri(uri)
            }
        }

    private val saveAsLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            if (uri != null) saveTo(uri, isSaveAs = true)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContentView(R.layout.activity_main)

        session = PdfSession(this)
        toolbar = findViewById(R.id.toolbar)
        recycler = findViewById(R.id.pages)
        hscroll = findViewById(R.id.hscroll)
        emptyView = findViewById(R.id.empty)
        hintBar = findViewById(R.id.hint)
        progress = findViewById(R.id.progress)
        zoomBar = findViewById(R.id.zoomBar)
        zoomLabel = findViewById(R.id.zoomLabel)

        findViewById<View>(R.id.btnZoomIn).setOnClickListener { stepZoom(+1) }
        findViewById<View>(R.id.btnZoomOut).setOnClickListener { stepZoom(-1) }
        scaleDetector = ScaleGestureDetector(this, PinchListener()).apply { isQuickScaleEnabled = false }

        pageAdapter = PageAdapter(lifecycleScope) { page, x, y -> onPageTapped(page, x, y) }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = pageAdapter
        recycler.itemAnimator = null

        toolbar.inflateMenu(R.menu.main)
        toolbar.setOnMenuItemClickListener { onMenu(it.itemId); true }
        findViewById<View>(R.id.btnOpen).setOnClickListener { openLauncher.launch(arrayOf("application/pdf")) }

        hscroll.addOnLayoutChangeListener { _, l, _, r, _, ol, _, or, _ ->
            if (r - l != or - ol) applyZoom()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    textMode -> setTextMode(false)
                    session.dirty -> confirmDiscard { finish() }
                    else -> finish()
                }
            }
        })

        updateUi()
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        pageAdapter.close()
        super.onDestroy()
    }

    private fun handleIntent(intent: Intent?) {
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            else -> null
        }
        if (uri != null) {
            if (session.dirty) confirmDiscard { openUri(uri) } else openUri(uri)
        }
    }

    // ------------------------------------------------------------------ menu

    private fun onMenu(id: Int) {
        if (busy) return
        when (id) {
            R.id.action_open -> {
                if (session.dirty) confirmDiscard { openLauncher.launch(arrayOf("application/pdf")) }
                else openLauncher.launch(arrayOf("application/pdf"))
            }
            R.id.action_text -> setTextMode(!textMode)
            R.id.action_form -> showFormDialog()
            R.id.action_undo -> undo()
            R.id.action_zoom -> zoomTo(1f, hscroll.width / 2f, hscroll.height / 2f)
            R.id.action_save -> save()
            R.id.action_save_as -> saveAsLauncher.launch(suggestedCopyName())
            R.id.action_share -> share()
        }
    }

    private fun updateUi() {
        emptyView.visibility = if (hasDocument) View.GONE else View.VISIBLE
        hscroll.visibility = if (hasDocument) View.VISIBLE else View.GONE
        hintBar.visibility = if (textMode) View.VISIBLE else View.GONE
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        zoomBar.visibility = if (hasDocument) View.VISIBLE else View.GONE
        zoomLabel.text = "${(zoom * 100).roundToInt()}%"

        toolbar.title = if (hasDocument) currentName else getString(R.string.app_name)
        toolbar.subtitle = if (session.dirty) "Modifiche non salvate" else null

        val m = toolbar.menu
        m.findItem(R.id.action_text).apply {
            isVisible = hasDocument
            title = if (textMode) "Fine" else "Scrivi"
        }
        m.findItem(R.id.action_save).isVisible = hasDocument
        m.findItem(R.id.action_form).isVisible = hasDocument
        m.findItem(R.id.action_undo).apply { isVisible = hasDocument; isEnabled = session.canUndo }
        m.findItem(R.id.action_zoom).isVisible = hasDocument
        m.findItem(R.id.action_save_as).isVisible = hasDocument
        m.findItem(R.id.action_share).isVisible = hasDocument
    }

    private fun setTextMode(on: Boolean) {
        textMode = on
        updateUi()
    }

    private fun applyZoom() {
        val base = hscroll.width
        if (base == 0) return
        val w = (base * zoom).roundToInt()
        if (recycler.layoutParams.width != w) {
            recycler.layoutParams = recycler.layoutParams.apply { width = w }
            recycler.post { pageAdapter.notifyDataSetChanged() }
        }
    }

    /** Passa al livello di zoom successivo (+1) o precedente (-1), centrato sullo schermo. */
    private fun stepZoom(dir: Int) {
        if (!hasDocument || busy) return
        val next = if (dir > 0) zoomSteps.firstOrNull { it > zoom + 0.01f } ?: maxZoom
        else zoomSteps.lastOrNull { it < zoom - 0.01f } ?: minZoom
        zoomTo(next, hscroll.width / 2f, hscroll.height / 2f)
    }

    /**
     * Cambia lo zoom tenendo fermo il punto (fx, fy) dello schermo,
     * in pixel dall'angolo in alto a sinistra dell'area delle pagine.
     */
    private fun zoomTo(target: Float, fx: Float, fy: Float) {
        val newZoom = target.coerceIn(minZoom, maxZoom)
        val ratio = newZoom / zoom
        if (abs(ratio - 1f) < 0.01f) return

        val contentX = hscroll.scrollX + fx
        val lm = recycler.layoutManager as LinearLayoutManager
        val child = recycler.findChildViewUnder(contentX, fy)
            ?: lm.findViewByPosition(lm.findFirstVisibleItemPosition())
        val pos = child?.let { lm.getPosition(it) } ?: RecyclerView.NO_POSITION
        val top = child?.top ?: 0

        zoom = newZoom
        applyZoom()
        val offset = (fy - (fy - top) * ratio).roundToInt()
        if (pos != RecyclerView.NO_POSITION) lm.scrollToPositionWithOffset(pos, offset)
        val newScrollX = (contentX * ratio - fx).roundToInt().coerceAtLeast(0)
        hscroll.doOnNextLayout {
            hscroll.scrollTo(newScrollX, 0)
            // ripete dopo che le pagine hanno preso la nuova altezza
            if (pos != RecyclerView.NO_POSITION) recycler.post {
                if (pos < pageAdapter.itemCount) lm.scrollToPositionWithOffset(pos, offset)
            }
        }
        updateUi()
    }

    private inner class PinchListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
            if (!hasDocument || busy || hscroll.width == 0) return false
            val loc = IntArray(2)
            hscroll.getLocationInWindow(loc)
            pinchFx = d.focusX - loc[0]
            pinchFy = d.focusY - loc[1]
            if (pinchFx < 0 || pinchFy < 0 || pinchFx > hscroll.width || pinchFy > hscroll.height) return false
            pinching = true
            pinchStartZoom = zoom
            pinchFactor = 1f
            recycler.pivotX = hscroll.scrollX + pinchFx
            recycler.pivotY = pinchFy
            return true
        }

        override fun onScale(d: ScaleGestureDetector): Boolean {
            // durante il gesto ingrandisce solo l'immagine già disegnata (veloce);
            // le pagine vengono ridisegnate nitide alla fine
            pinchFactor = (pinchFactor * d.scaleFactor)
                .coerceIn(minZoom / pinchStartZoom, maxZoom / pinchStartZoom)
            recycler.scaleX = pinchFactor
            recycler.scaleY = pinchFactor
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            recycler.scaleX = 1f
            recycler.scaleY = 1f
            zoomTo(pinchStartZoom * pinchFactor, pinchFx, pinchFy)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (hasDocument) {
            scaleDetector.onTouchEvent(ev)
            if (pinching) {
                // le dita servono allo zoom: annulla scorrimento e tocchi sulle pagine
                if (!childrenCancelled) {
                    val cancel = MotionEvent.obtain(ev).apply { action = MotionEvent.ACTION_CANCEL }
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    childrenCancelled = true
                }
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                    pinching = false
                    childrenCancelled = false
                }
                return true
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------- apertura

    private fun openUri(uri: Uri) {
        runBusy {
            try {
                withContext(Dispatchers.IO) { session.load(uri) }
                pageAdapter.setFile(session.workFile)
            } catch (e: Exception) {
                hasDocument = false
                currentUri = null
                session.markSaved()
                if (e is SecurityException || (e.message ?: "").contains("password", true))
                    error("Il PDF è protetto da password e non può essere aperto.")
                error("Impossibile aprire questo file. Forse non è un PDF valido.")
            }
            currentUri = uri
            currentName = queryName(uri) ?: "documento.pdf"
            hasDocument = true
            textMode = false
            recycler.scrollToPosition(0)
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        uri.lastPathSegment?.substringAfterLast('/')
    }

    // ---------------------------------------------------------------- testo

    private fun onPageTapped(page: Int, x: Float, y: Float) {
        if (!textMode || busy) return

        val pad = dp(20)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(8), pad, 0)
        }
        val input = EditText(this).apply {
            hint = "Es. Mario Rossi"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 1
            maxLines = 5
        }
        box.addView(input)
        box.addView(TextView(this).apply {
            text = "Grandezza"
            setPadding(0, dp(12), 0, 0)
        })
        val sizes = listOf("Piccolo" to 9f, "Normale" to 11f, "Grande" to 14f, "Molto grande" to 18f)
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val groupScroll = HorizontalScrollView(this).apply { addView(group) }
        sizes.forEachIndexed { i, (label, size) ->
            group.addView(RadioButton(this).apply {
                id = 1000 + i
                text = label
                isChecked = size == lastFontSize
            })
        }
        if (group.checkedRadioButtonId == -1) group.check(1001)
        box.addView(groupScroll)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Scrivi qui")
            .setView(box)
            .setPositiveButton("Inserisci") { _, _ ->
                val text = input.text.toString().trimEnd()
                if (text.isBlank()) return@setPositiveButton
                val size = sizes[(group.checkedRadioButtonId - 1000).coerceIn(0, sizes.size - 1)].second
                lastFontSize = size
                // il tocco indica il centro della prima riga
                val top = (y - size * 0.6f).coerceAtLeast(0f)
                runEdit { session.addText(page, x, top, text, size) }
            }
            .setNegativeButton("Annulla", null)
            .create()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        input.requestFocus()
    }

    // --------------------------------------------------------------- moduli

    private fun showFormDialog() {
        runBusy(refresh = false) {
            val info = withContext(Dispatchers.IO) { session.readForm() }
            if (info.fields.isEmpty()) {
                val msg = if (info.isXfaOnly)
                    "Questo modulo usa un formato speciale (XFA) che l'app non supporta. Puoi comunque usare \"Scrivi\" per mettere il testo dove vuoi."
                else
                    "Questo PDF non ha campi compilabili.\n\nUsa \"Scrivi\" e tocca il punto del foglio dove vuoi inserire il testo."
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Nessun campo")
                    .setMessage(msg)
                    .setPositiveButton("Usa Scrivi") { _, _ -> setTextMode(true) }
                    .setNegativeButton("Chiudi", null)
                    .show()
            } else {
                buildFormDialog(info.fields)
            }
        }
    }

    private fun buildFormDialog(fields: List<PdfSession.Field>) {
        val pad = dp(20)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(8), pad, dp(8))
        }
        val readers = mutableMapOf<String, () -> String>()

        for (f in fields) {
            when (f.kind) {
                PdfSession.Kind.TEXT -> {
                    list.addView(label(f.label))
                    val e = EditText(this).apply {
                        setText(f.value)
                        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
                            (if (f.multiline) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0)
                    }
                    list.addView(e)
                    readers[f.name] = { e.text.toString() }
                }
                PdfSession.Kind.CHECK -> {
                    val c = CheckBox(this).apply {
                        text = f.label
                        isChecked = f.value.isNotEmpty()
                        setPadding(0, dp(6), 0, dp(6))
                    }
                    list.addView(c)
                    readers[f.name] = { if (c.isChecked) "1" else "" }
                }
                PdfSession.Kind.CHOICE -> {
                    list.addView(label(f.label))
                    val opts = listOf("—") + f.options
                    val s = Spinner(this).apply {
                        adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, opts)
                        setSelection(opts.indexOf(f.value).coerceAtLeast(0))
                    }
                    list.addView(s)
                    readers[f.name] = { if (s.selectedItemPosition <= 0) "" else opts[s.selectedItemPosition] }
                }
            }
        }

        val scroll = ScrollView(this).apply { addView(list) }
        AlertDialog.Builder(this)
            .setTitle("Compila il modulo")
            .setView(scroll)
            .setPositiveButton("Applica") { _, _ ->
                // salva solo i campi effettivamente cambiati
                val changed = fields.mapNotNull { f ->
                    val v = readers[f.name]?.invoke() ?: return@mapNotNull null
                    if (v != f.value) f.name to v else null
                }.toMap()
                if (changed.isEmpty()) return@setPositiveButton
                runEdit {
                    val failed = session.fillForm(changed)
                    if (failed.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            toast("Alcuni campi non sono stati compilati (${failed.size}). Prova con \"Scrivi\".")
                        }
                    }
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setPadding(0, dp(12), 0, 0)
        textSize = 13f
    }

    // ---------------------------------------------------------- salvataggio

    private fun undo() {
        if (!session.canUndo) return
        runBusy {
            withContext(Dispatchers.IO) { session.undo() }
            pageAdapter.setFile(session.workFile)
        }
    }

    private fun save() {
        val uri = currentUri
        if (uri == null) {
            saveAsLauncher.launch(suggestedCopyName()); return
        }
        saveTo(uri, isSaveAs = false)
    }

    private fun saveTo(uri: Uri, isSaveAs: Boolean) {
        lifecycleScope.launch {
            busy = true; updateUi()
            val ok = withContext(Dispatchers.IO) {
                try {
                    val out = try {
                        contentResolver.openOutputStream(uri, "wt")
                    } catch (_: Exception) {
                        contentResolver.openOutputStream(uri, "w")
                    } ?: error("no stream")
                    out.use { o -> session.workFile.inputStream().use { it.copyTo(o) } }
                    true
                } catch (_: Exception) {
                    false
                }
            }
            busy = false
            if (ok) {
                session.markSaved()
                if (isSaveAs) {
                    currentUri = uri
                    currentName = queryName(uri) ?: currentName
                }
                toast("Salvato")
            } else if (!isSaveAs) {
                toast("Non posso sovrascrivere questo file: scegli dove salvare una copia")
                saveAsLauncher.launch(suggestedCopyName())
            } else {
                toast("Salvataggio non riuscito")
            }
            updateUi()
        }
    }

    private fun suggestedCopyName(): String {
        val base = currentName.removeSuffix(".pdf").removeSuffix(".PDF")
        return "$base (compilato).pdf"
    }

    private fun share() {
        try {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val f = File(dir, currentName.ifBlank { "documento.pdf" })
            session.workFile.copyTo(f, overwrite = true)
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Condividi PDF"))
        } catch (e: Exception) {
            toast("Impossibile condividere: ${e.message}")
        }
    }

    // ----------------------------------------------------------------- utilità

    /** Esegue una modifica al PDF e poi aggiorna la visualizzazione. */
    private fun runEdit(block: suspend () -> Unit) {
        runBusy {
            withContext(Dispatchers.IO) { block() }
            pageAdapter.setFile(session.workFile)
        }
    }

    private fun runBusy(refresh: Boolean = true, block: suspend () -> Unit) {
        if (busy) return
        lifecycleScope.launch {
            busy = true; updateUi()
            try {
                block()
            } catch (e: IllegalArgumentException) {
                // tipicamente: carattere non supportato dal font
                showError("Il testo contiene caratteri non supportati (es. emoji o alfabeti non latini).")
            } catch (e: IllegalStateException) {
                showError(e.message ?: "Errore")
            } catch (e: OutOfMemoryError) {
                showError("Il documento è troppo grande per la memoria del telefono.")
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                showError(
                    if (msg.contains("password", true)) "Il PDF è protetto da password e non può essere aperto."
                    else "Si è verificato un errore:\n$msg"
                )
            } finally {
                busy = false
                updateUi()
            }
        }
    }

    private fun showError(msg: String) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun confirmDiscard(then: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("Modifiche non salvate")
            .setMessage("Hai delle modifiche non salvate. Vuoi perderle?")
            .setPositiveButton("Perdi modifiche") { _, _ -> session.markSaved(); then() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
